package com.ifma.aluguel.locacao;

import org.junit.jupiter.api.Test;

public class LocacaoTest {

    @Test
    public void locacaoCreatTest(){

    }

    @Test
    public void locacaoReadTest(){

    }

    @Test
    public void locacaoUpdateTest(){

    }

    @Test
    public void locacaoDeleteTest(){

    }

    @Test
    public void verificaCalculoValorAluguelSemMulta(){

    }

    @Test
    public void verificaCalculoValorAluguelComMulta(){

    }
}
