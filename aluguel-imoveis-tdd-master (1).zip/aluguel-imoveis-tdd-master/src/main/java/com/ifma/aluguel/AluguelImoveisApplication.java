package com.ifma.aluguel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AluguelImoveisApplication {

	public static void main(String[] args) {
		SpringApplication.run(AluguelImoveisApplication.class, args);
	}

}
